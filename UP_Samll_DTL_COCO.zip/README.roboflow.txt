
TRd - v1 20210617 1237pmDTL
==============================

This dataset was exported via roboflow.ai on June 17, 2021 at 7:11 AM GMT

It includes 99 images.
N are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


